const Sequelize = require("sequelize");
const conexão = new Sequelize("projeto","root","Z16682604l",{
    host: "localhost",
    dialect: "mysql"
});


(async ()=>{ await conexão.authenticate(), console.log("Conexão foi bem sucedida!")})();

module.exports = conexão;