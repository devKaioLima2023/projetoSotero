const Sequelize = require("sequelize");
const conexão = require("./conexão");

const Administrador = conexão.define("administrador", {
  nome:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  sobrenome:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  telefone:{
    type: Sequelize.INTEGER,
    allowNull: false,
  },
  nacionalidade:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  cpf:{
    type: Sequelize.INTEGER,
    allowNull: false,
  },
  rg:{
    type: Sequelize.INTEGER,
    allowNull: false,
  },
  endereco:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  nome_da_mae:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  nome_do_pai:{
    type: Sequelize.STRING,
    allowNull: false,
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  senha: {
    type: Sequelize.STRING,
    allowNull: false,
  }
});

Administrador.sync({force: false});

module.exports = Administrador;
